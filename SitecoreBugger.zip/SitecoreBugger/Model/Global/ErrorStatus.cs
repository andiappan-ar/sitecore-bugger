﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SitecoreBugger.Site.Model.Global
{
    public class ErrorStatus
    {
        public int ErrorId { get; set; }
        public string IsSuccess { get; set; }      
      
    }
}