﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SitecoreBugger.Site.Model.Global
{
    public class ValuePair
    {
        public int EId { get; set; }
        public string EDisplayName { get; set; }
    }
}