﻿using Sitecore.Mvc.Pipelines.Response.RenderRendering;
using Sitecore.Mvc.Presentation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace SitecoreBugger.Site.Sitecore.PipeLine
{
    public class SCBRenderingLogs : ExecuteRenderer
    {
        protected override bool Render(Renderer renderer, TextWriter writer, RenderRenderingArgs args)
        {
            Guid id = Guid.NewGuid();
            string dynamicId = "scbugger-log-id-" + id.ToString();

            // This will write log information about all renderings
            writer.WriteLine($"<scbugger-log id=\"{dynamicId}\" rendering=\"{args.Rendering.RenderingItemPath}\" datasource=\"{args.Rendering.DataSource}\" placeholder=\"{args.Rendering.Placeholder}\"  renderer=\"{args.Rendering.Renderer.ToString()}\"></scbugger-log>");

            return base.Render(renderer, writer, args);
        }
    }
}