﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SitecoreBugger.Site.Utilities
{
    public static class Settings
    {
        public static string CS = "Data Source=PC387797\\SQLDVP201664;Initial Catalog=dummy;User ID=sa;Password=password-1";
        public static string ScreenSHotURLPrefix = "/sc-bugger/scbdashboard/GetErrorScreenShot?errorId=";
    }
}